-- the Group the orders by date and calculate the average number of pizzas ordered per day.

SELECT 
    AVG(quantity)
FROM
    (SELECT 
        pizzahut.orders.order_date AS orderdate,
            SUM(pizzahut.order_details.quantity) AS quantity
    FROM
        pizzahut.orders
    JOIN pizzahut.order_details ON pizzahut.orders.order_id = pizzahut.order_details.order_id
    GROUP BY pizzahut.orders.order_date) AS avgquantity;