-- Calculate the total revenue generated from pizza sales.


SELECT 
    round(SUM(pizzahut.order_details.quantity * pizzahut.pizzas.price), 2) AS total_sales
FROM
    pizzahut.order_details
        JOIN
    pizzahut.pizzas ON pizzas.pizza_id = order_details.pizza_id
