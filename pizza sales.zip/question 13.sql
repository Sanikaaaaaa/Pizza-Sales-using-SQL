-- Determine the top 3 most ordered pizza types based on revenue for each pizza category.

select name, revenue from 
(select category, name, revenue, rank() over(partition by category order by revenue desc) as rnk
 from
(SELECT 
    pizzahut.pizza_types.category, pizzahut.pizza_types.name, sum(quantity * price) AS revenue
FROM
    pizzahut.pizza_types
        JOIN
    pizzahut.pizzas ON pizzahut.pizza_types.pizza_type_id = pizzahut.pizzas.pizza_type_id
        JOIN
    order_details ON pizzahut.order_details.pizza_id = pizzahut.pizzas.pizza_id
    group by pizzahut.pizza_types.category, pizzahut.pizza_types.name) as category) as b
    where rnk <= 3;
