SELECT * FROM pizzahut.orders;

-- Retrieve the total number of orders placed.

select count(order_id) as total_orders from pizzahut.orders;