-- Identify the most common pizza size ordered.



SELECT 
    pizzas.size,
    COUNT(order_details.order_details_id) AS order_detailsid
FROM
    pizzahut.order_details
        JOIN
    pizzahut.pizzas ON pizzahut.order_details.pizza_id = pizzahut.pizzas.pizza_id
GROUP BY size
ORDER BY order_detailsid DESC;