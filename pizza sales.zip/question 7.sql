-- Determine the distribution of orders by hour of the day.

SELECT 
    HOUR(pizzahut.orders.order_time) AS hourorder,
    COUNT(order_id) AS idorder
FROM
    pizzahut.orders
GROUP BY hourorder;