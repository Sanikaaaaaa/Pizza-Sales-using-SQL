-- Join relevant tables to find the category-wise distribution of pizzas.

SELECT 
    pizzahut.pizza_types.category,
    COUNT(pizzahut.pizza_types.name) AS name
FROM
    pizzahut.pizza_types
GROUP BY pizzahut.pizza_types.category;