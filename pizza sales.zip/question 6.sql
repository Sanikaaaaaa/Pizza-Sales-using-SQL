--  Join the necessary tables 
-- to find the total quantity of each pizza category ordered.

SELECT 
    pizzahut.pizza_types.category,
    SUM(pizzahut.order_details.quantity) AS quantity
FROM
    pizzahut.pizza_types
        JOIN
    pizzahut.pizzas ON pizzahut.pizza_types.pizza_type_id = pizzahut.pizzas.pizza_type_id
        JOIN
    pizzahut.order_details ON pizzahut.order_details.pizza_id = pizzahut.pizzas.pizza_id
GROUP BY pizzahut.pizza_types.category
ORDER BY quantity DESC;