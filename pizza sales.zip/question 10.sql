-- Determine the top 3 most ordered pizza types based on revenue.

SELECT 
    pizzahut.pizza_types.name, sum(quantity * price) AS revenue
FROM
    pizzahut.pizza_types
        JOIN
    pizzahut.pizzas ON pizzahut.pizza_types.pizza_type_id = pizzahut.pizzas.pizza_type_id
        JOIN
    order_details ON pizzahut.order_details.pizza_id = pizzahut.pizzas.pizza_id
    group by pizzahut.pizza_types.name
    order by revenue desc limit 3;