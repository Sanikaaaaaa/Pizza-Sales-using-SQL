-- Analyze the cumulative revenue generated over time.

select order_date, sum(revenue) over (order by order_date) as cum_revenue
from
(SELECT 
    pizzahut.orders.order_date, round(SUM(quantity * price), 2) AS revenue
FROM
    pizzahut.orders
        JOIN
    pizzahut.order_details ON pizzahut.orders.order_id = pizzahut.order_details.order_id
        JOIN
    pizzahut.pizzas ON pizzahut.pizzas.pizza_id = pizzahut.order_details.pizza_id
GROUP BY pizzahut.orders.order_date) as totalsales; 