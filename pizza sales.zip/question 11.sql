-- Calculate the percentage contribution of each pizza type to total revenue.

SELECT 
    pizzahut.pizza_types.category, round(sum(quantity * price) / (SELECT 
    round(SUM(pizzahut.order_details.quantity * pizzahut.pizzas.price), 2) AS total_sales
FROM
    pizzahut.order_details
        JOIN
    pizzahut.pizzas ON pizzas.pizza_id = order_details.pizza_id) * 100, 2) as totalsales
FROM
    pizzahut.pizza_types
        JOIN
    pizzahut.pizzas ON pizzahut.pizza_types.pizza_type_id = pizzahut.pizzas.pizza_type_id
        JOIN
    order_details ON pizzahut.order_details.pizza_id = pizzahut.pizzas.pizza_id
    group by pizzahut.pizza_types.category;